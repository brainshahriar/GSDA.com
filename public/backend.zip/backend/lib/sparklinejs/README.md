jQuery Sparklines
=================

This jQuery plugin makes it easy to generate a number of different types
of sparklines directly in the browser, using online a line of two of HTML 
and Javascript.

The plugin has no dependencies other than jQuery and works with all modern 
browsers and also Internet Explorer 6 and later (excanvas is not required
for IE support).

See the [jQuery Sparkline project page](http://omnipotent.net/jquery.sparkline/)
for live examples and documentation.

## License

Released under the New BSD License

(c) Splunk, Inc 2012
